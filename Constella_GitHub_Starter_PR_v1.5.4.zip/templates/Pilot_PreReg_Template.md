# Pilot Pre‑Registration Template
- **Hypothesis (falsifiable):** 
- **Observables & Instruments (units, sampling, calibration):** 
- **Design (control/comparison, sample size, analysis plan):** 
- **Pass/Fail thresholds (primary/secondary):** 
- **Disclosure (funding, conflicts of interest):** 
- **Publication plan (CSV, plots, protocol):** 
