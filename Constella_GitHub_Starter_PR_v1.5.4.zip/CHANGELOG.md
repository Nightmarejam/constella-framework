# Changelog

All notable changes to this project will be documented in this file. We follow **SemVer**.

## v1.5.4 — 2025-08-12
- Add **Start here** progressive steps in README
- Add **AI/Human review blocks** and **tracker template**
- Add **Thread Charter** and **Pilot Pre‑Reg** templates
- Add **Overview** with evidence levels & labels
- Add **Contributor Covenant** and **Contributing** guide
- Add **Security** policy
