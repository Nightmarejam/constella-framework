# Penumbra Accord (WIP)
Restorative flow: declare harm → mediation → repair contract → reintegration.
