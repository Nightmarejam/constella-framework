# Civic Tome (WIP)
Versioned corpus of protocols, precedents, and rulings.
