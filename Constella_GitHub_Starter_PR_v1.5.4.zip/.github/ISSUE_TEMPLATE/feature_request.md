---
name: Feature request
about: Suggest an idea or module improvement
labels: enhancement
---
**Problem**
What problem are you trying to solve?

**Proposal**
Describe the improvement.

**Evidence/Labels**
What evidence level? What label (stable/contested/speculative)?

**Additional context**
